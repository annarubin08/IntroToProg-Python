#-------------------------------------------------#
#Title: Working with Functions
#Dev:   Anna Rubin
#Date:  August 20, 2018
#-------------------------------------------------#

#The following code opens and reads a to do list and
#asks the user if they would like to show the current list,
#add data to the list, remove data from the list,
#save the list, or exit.

#-------------------------------------------------#

#Open file and create dictionary and list to store data
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

#-------------------------------------------------#

#Create a function to load existing data in text file
def LoadData():
    objFile = open(objFileName, "r")
    for line in objFile:
        strData = line.split(",") # readline() reads a line of the data into 2 elements
        dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
        lstTable.append(dicRow)
    objFile.close()

#-------------------------------------------------#

#Create a class to hold functions
class MenuOptions(object):
    #Create a function to show current data
    @staticmethod
    def ShowData():
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    #Create a function to add a new item
    @staticmethod
    def AddItem():
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)

    #Create a function to remove a row of data
    @staticmethod
    def RemoveItem():
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  #Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  #the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            #end if
            intRowNumber += 1
        #end for loop
        #Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    #Create a function to save data to a text file
    @staticmethod
    def SaveData():
        #Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

#-------------------------------------------------#

#Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    #If user chooses (1), call the function to show current data in the list/table
    if (strChoice.strip() == '1'):
        LoadData()
        MenuOptions.ShowData()

    #If user chooses (2), call the function to add a new item to the list/table
    elif(strChoice.strip() == '2'):
        LoadData()
        MenuOptions.AddItem()
        MenuOptions.ShowData()

    #If user chooses (3), remove an item from the list/table
    elif(strChoice == '3'):
        LoadData()
        MenuOptions.RemoveItem()
        MenuOptions.ShowData()

    #If user chooses (4), save tasks to the text file
    elif(strChoice == '4'):
        LoadData()
        MenuOptions.SaveData()
        MenuOptions.ShowData()

    #If user chooses (5), exit program
    elif (strChoice == '5'):
        break